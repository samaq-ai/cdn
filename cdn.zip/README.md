[![Build Status](https://travis-ci.com/samaq-ai/cdn.svg?branch=master)](https://travis-ci.com/samaq-ai/cdn)
![Sama Business Service Framework](https://github.com/samaq-ai/cdn/workflows/Sama%20Business%20Service%20Framework/badge.svg?branch=master)
## sbs
Sama Business Services Framework


