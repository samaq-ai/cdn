exports.printMsg = function() {
    console.log("Welcome to Sama Buisness Services Terminal | Written with NodeJS")
  }